//
//  ViewController.m
//  PopToShareView
//
//  Created by ZhuKK on 2018/1/23.
//  Copyright © 2018年 ZhuKK. All rights reserved.
//

#import "ViewController.h"
#import "ZKKShareView.h"

@interface ViewController ()<ZKKShareViewDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    ZKKShareView * shareVeiw = [[ZKKShareView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    shareVeiw.delegate = self;
    [shareVeiw show];
}
-(void)ZKKShareViewDidSelecteBtnWithBtnText:(NSString *)btText{
    
    NSLog(@"---btText-%@",btText);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
