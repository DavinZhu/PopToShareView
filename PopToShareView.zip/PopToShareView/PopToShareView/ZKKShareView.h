//
//  ZKKShareView.h
//  SuperAPP
//
//  Created by ZhuKK on 2018/1/18.
//  Copyright © 2018年 ZhuKK. All rights reserved.
//

#import <UIKit/UIKit.h>


// 代理方法  判断点击了那个button
@protocol ZKKShareViewDelegate <NSObject>

- (void)ZKKShareViewDidSelecteBtnWithBtnText:(NSString *)btText;


@end

@interface ZKKShareView : UIView

@property (nonatomic, weak) id <ZKKShareViewDelegate> delegate;

- (void)show;

@end
