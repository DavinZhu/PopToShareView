//
//  ZKKShareView.m
//  SuperAPP
//
//  Created by ZhuKK on 2018/1/18.
//  Copyright © 2018年 ZhuKK. All rights reserved.
//

#import "ZKKShareView.h"
#import <POP.h>
#import "UIButton+MBHExpand.h"
#import "UIView+Frame.h"

#define Share_Height 140


#define APP_Width [UIScreen mainScreen].bounds.size.width
#define APP_Height [UIScreen mainScreen].bounds.size.height

#define WIDTH  APP_Width/375
#define HEIGHT  APP_Height/667

#define Status_Height (APP_Height>740 ? 44:20)
#define Bottom_Height (APP_Height>740 ? 34:0)

//带有RGBA的颜色设置
#define RGB_Alpha(R, G, B, A) [UIColor colorWithRed:R/255.0 green:G/255.0 blue:B/255.0 alpha:A]

#define Gray_Text_COLOR      RGB_Alpha(154, 154, 154, 1) //灰色字体的9A9A9A颜色
#define Block_Text_COLOR      RGB_Alpha(0, 0, 0, 1) //黑色字体的颜色
#define Gray_View_COLOR      RGB_Alpha(240, 239,244, 1) //空白背景的颜色


@interface ZKKShareView ()

@property(strong,nonatomic)UIView * bottomBgView;


@end

@implementation ZKKShareView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.5];
        [self createSubViews];
    }
    return self;
}
- (void)createSubViews {
    self.clipsToBounds = YES;
    self.bottomBgView = [[UIView alloc]initWithFrame:CGRectMake(0, APP_Height - Share_Height-Bottom_Height, APP_Width, Share_Height+Bottom_Height)];
    self.bottomBgView.backgroundColor = [UIColor whiteColor];
    self.userInteractionEnabled = NO;
    [self addSubview:self.bottomBgView];
    
    UIView * lineView = [[UIView alloc]initWithFrame:CGRectMake(0, self.bottomBgView.ZKK_height-48-Bottom_Height, APP_Width, 8)];
    lineView.backgroundColor = Gray_View_COLOR;
    [self.bottomBgView addSubview:lineView];
    
    UIButton *cancelBt = [[UIButton alloc]initWithFrame:CGRectMake(0, self.bottomBgView.ZKK_height-Bottom_Height - 40-Bottom_Height, APP_Width, 40+Bottom_Height)];
    [cancelBt setTitle:@"取消" forState:UIControlStateNormal];
    [cancelBt setTitleColor:Gray_Text_COLOR forState:UIControlStateNormal];
    cancelBt.titleLabel.font = [UIFont systemFontOfSize:15];
    [cancelBt addTarget:self action:@selector(cancelAnimation) forControlEvents:UIControlEventTouchUpInside];
    [self.bottomBgView addSubview:cancelBt];
    
    CGFloat buttonWidth = 60;
    NSArray *imageArray = @[@"weixinShar",@"weixinFrindShar",@"weiboShar"];
    NSArray *titleArray = @[@"微信",@"朋友圈",@"微博"];
    
    for (NSInteger i = 0;  i < imageArray.count;i++) {
        
        NSString *imageStr = imageArray[i];
        NSString *titleStr = titleArray[i];
        CGFloat maigin = (APP_Width - imageArray.count*buttonWidth)/(imageArray.count + 1);
        
        UIButton * topButton = [[UIButton alloc]initWithFrame:CGRectMake(maigin + i * (buttonWidth + maigin), -APP_Height/2, 0, 0)];
        [topButton setImage:[UIImage imageNamed:imageStr] forState:UIControlStateNormal];
        [topButton addTarget:self action:@selector(BtnClick:) forControlEvents:UIControlEventTouchUpInside];
        [topButton setTitleColor:Block_Text_COLOR forState:UIControlStateNormal];
        topButton.titleLabel.font = [UIFont systemFontOfSize:12];
        
        [self.bottomBgView addSubview:topButton];
        
        //添加动画
        POPSpringAnimation *anim = [POPSpringAnimation animationWithPropertyNamed:kPOPViewFrame];
        anim.springSpeed = 5;
        anim.springBounciness = 10;
        anim.beginTime = CACurrentMediaTime() + 0.05 * i;
        anim.fromValue = [NSValue valueWithCGRect:CGRectMake(topButton.ZKK_x, -APP_Height/2, buttonWidth, buttonWidth+10)] ;
        anim.toValue =   [NSValue valueWithCGRect:CGRectMake(topButton.ZKK_x, 10, buttonWidth, buttonWidth+10)] ;
        [topButton pop_addAnimation:anim forKey:nil];
        
        [anim setCompletionBlock:^(POPAnimation *anim, BOOL finished) {
            [topButton setTitle:titleStr forState:UIControlStateNormal];
            [topButton layoutButtonWithEdgeInsetsStyle:MKButtonEdgeInsetsStyleTop imageTitleSpace:0.f];
            self.userInteractionEnabled = YES;
        }];
    }
    
    //    UIButton *plus = [UIButton buttonWithType:UIButtonTypeCustom];
    //    plus.backgroundColor = [UIColor orangeColor];
    //    plus.frame = CGRectMake((APP_Width - 25) / 2, self.bottomBgView.ZKK_height-Bottom_Height - 35, 25, 25);
    //    [plus setBackgroundImage:[UIImage imageNamed:@"close_share_icon"] forState:UIControlStateNormal];
    //    [plus addTarget:self action:@selector(cancelAnimation) forControlEvents:UIControlEventTouchUpInside];
    //    [self.bottomBgView addSubview:plus];
    //
    //    [UIView animateWithDuration:0.2 animations:^{
    //        plus.transform = CGAffineTransformMakeRotation(M_PI_2);
    //    }];
    
    
    
}
- (void)show {
    UIWindow *keyWindown = [UIApplication sharedApplication].keyWindow;
    [keyWindown addSubview:self];
}

- (void)BtnClick:(UIButton *)btn {
    
    if ([_delegate respondsToSelector:@selector(ZKKShareViewDidSelecteBtnWithBtnText:)]) {
        [self.delegate ZKKShareViewDidSelecteBtnWithBtnText:btn.titleLabel.text];
    }
    [self cancelAnimation];
}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [self cancelAnimation];
}
- (void)cancelAnimation {
    
    self.userInteractionEnabled = NO;
    int beginI = 2;
    for (int i = beginI ; i < self.bottomBgView.subviews.count; i++) {
        
        UIView *currentView = self.bottomBgView.subviews[i];
        
        POPBasicAnimation *anim = [POPBasicAnimation animationWithPropertyNamed:kPOPViewCenter];
        CGFloat endY = currentView.ZKK_y + self.bottomBgView.ZKK_height+44;
        
        anim.toValue = [NSValue valueWithCGPoint:CGPointMake(currentView.ZKK_centerX, endY)];
        anim.beginTime = CACurrentMediaTime() + i * 0.05;
        [currentView pop_addAnimation:anim forKey:nil];
        
        //监听最后一个动画
        if (i == self.bottomBgView.subviews.count - 3) {
            [anim setCompletionBlock:^(POPAnimation *anim, BOOL finished) {
                self.userInteractionEnabled = YES;
                [self removeFromSuperview];
            }];
        }
    }
    
}

@end
